# -*- coding: ISO-8859-1 -*-
""" check correct encoding declaration
"""

__revision__ = '����'

